/*
    1_3.h
    Jessica Authier
    0849720
    2017/02/13
*/
#include <stdio.h>
#include <stdlib.h>

int countInversions (int * A, int n);
int countInvMergesort (int *A, int n);
int merge(int * B, int * C, int * A, int p, int q);