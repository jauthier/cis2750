cis 3490
Assignment 2
2017/02/13

`````````````````````

Jessica Authier
0849720

`````````````````````

To Compile and run:
    Type: make
    Type: ./run

`````````````````````

The algorithms for the second question dont work. The brute force algorithm
seg faults durring the loop, I think it has something to do with the 
orientation function. The divide and conquer algorithm is not finished 
I was having trouble figuring out how to best merge the hulls.
