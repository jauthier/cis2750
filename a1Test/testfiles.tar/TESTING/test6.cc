#include<stdio.h>
#include<stdlib.h>


class A{
int a ;
   int fn (){
      a=3; } }
;


/* unusual formatting */

int main(int argc, char *argv[])
{
class A
myA;

   myA.fn() ;
   if (myA.a ==3)return(0);
   else return(1) ;
}

