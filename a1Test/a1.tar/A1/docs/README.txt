README.txt

CIS2750
````````
Assignment 1
`````````````

By: Jessica Authier
Date: 2017/01/29



Compiling and Running
``````````````````````

To compile:		make

To run:		./a1 fileName.cc


Limitations
````````````
	For overloading methods the proper method 
	is identified by how many parameters it has
	and takes no account of the types of the 
	parameters.
