cis 2750 - Assignment 2
''''''''''''''''''''''''
Jessica Authier
0849720
'''''''''
The post file does not use my A1
'''''''''''''''''''''''''''''''''

To compile the c files
	type make

to run the c files
	type ./post <username>
		 ./addauthor <username>

in the python file a2.py
	reading all the streams at once doesn't work
	O - ordering by username doesn't work
