/*
    translateConfig.h
    Author: Jessica Authier
    Date Modified: 2017/03/15
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void button (char * line, FILE * fp);

void executable (char * line, FILE * fp);

void headings (char * line, FILE * fp);

void input (char * line, FILE * fp);

void link (char * line, FILE * fp);

void pictures (char * line, FILE * fp);

void radioButton (char * line, FILE *fp);

void text (char * line, FILE * fp);