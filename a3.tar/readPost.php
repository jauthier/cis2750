<!DOCTYPE html>
<!--
readPost.php
-->
<html>
<head>
<title>Read Post</title>
</head>

<body>
<?php
    $username = $_POST["username"];
    $stream = $_POST["stream"];
    $action = $_POST["action"];
    $sort = $_POST["sort"];
    $currentPost = $_POST["currentPost"];
    if ($currentPost == "-1"){
        $command = "./getCP.py ".$username." ".$stream." ".$sort;
        exec($command,$output,$return);
        $currentPost = $output[0];
    }
    $s = $cp = $a = "";

    echo "<h2>Welcome $username</h2>";


    if ($_SERVER["REQUEST_METHOD"] == "POST"){
        $command = "./view.py ".$username." ".$stream." ".$action." ".$sort." ".$currentPost." 2>&1";
        exec($command, $out, $return);
        $i = $count = 0;
        $count = count($out);
	$count = $count - 1;
        for ($i=0;$i<$count;$i=$i+1){
            echo "$out[$i]<br>";
        }
        $currentPost = $out[$count];
    }
?>

<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" name="next">
    <input type="hidden" name="username" value="<?php echo $username; ?>">
    <input type="hidden" name="stream" value="<?php echo $stream; ?>">
    <input type="hidden" name="action" value="-n">
    <input type="hidden" name="sort" value="<?php echo $sort; ?>">
    <input type="hidden" name="currentPost" value="<?php echo $currentPost; ?>">
    <input type="submit" name="next" value="Next">
</form>

<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) ?>" name="previous">
    <input type="hidden" name="username" value="<?php echo $username; ?>">
    <input type="hidden" name="stream" value="<?php echo $stream; ?>">
    <input type="hidden" name="action" value="-p">
    <input type="hidden" name="sort" value="<?php echo $sort; ?>">
    <input type="hidden" name="currentPost" value="<?php echo $currentPost; ?>">
    <input type="submit" name="previous" value="Previous">
</form>

<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" name="sortByAuthor">
    <input type="hidden" name="username" value="<?php echo $username; ?>">
    <input type="hidden" name="stream" value="<?php echo $stream; ?>">
    <?php 
        if ($sort == "-d")
            $s = "-a";
        else
            $s = "-d";
        if ($stream == "all"){
            $cp = $currentPost;
            $a = "-r";
        } else {
            $command = "./getCP.py ".$username." ".$stream." ".$s;
            exec($command,$output,$return);
            $cp = $output[0];
            $a = "-c";
        }
    ?>
    <input type="hidden" name="action" value="<?php echo $a; ?>">
    <input type="hidden" name="sort" value="<?php echo $s; ?>">
    <input type="hidden" name="currentPost" value="<?php echo $cp; ?>">
    <input type="submit" name="sortByAuthor" value="Sort By Author">
</form>

<form method="post" action="readPost.php" name="getMostRecent">
    <input type="hidden" name="file" value="readPost.wpml">
    <input type="hidden" name="username" value="<?php echo $username; ?>">
    <input type="hidden" name="stream" value="<?php echo $stream; ?>">
    <input type="hidden" name="action" value="-r">
    <input type="hidden" name="sort" value="-d">
    <input type="hidden" name="currentPost" value="<?php echo $currentPost; ?>">
    <input type="submit" name="getMostRecent" value="Most Recent Post">
</form>

<form method="post" action="post.php" name="post">
    <input type="hidden" name="file" value="readPost.wpml">
    <input type="hidden" name="username" value="<?php echo $username ?>">
    <input type="submit" name="post" value="Post">
</form>

<form method="post" action="addauthor.php" name="addauthor">
    <input type="hidden" name="file" value="readPost.wpml">
    <input type="hidden" name="username" value="<?php echo $username ?>">
    <input type="submit" name="addauthor" value="Add Author">
</form>

<form action="login.php">
    <input type="submit" name="logout" value="Logout">
</form>

</body>
</html>
