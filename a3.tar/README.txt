Assignment 3
cis 2750
`````````

Jessica Authier
0849720

````````

I had some problems with permissions I fixed them on my account but
I am not sure if they will be a problem else where.

I did not make the php filies with the c program, they are all static.
The c program does work with the basic tags outlined in the assignment handout.

To view the website you must add "/login.php" to the end I couldn't get it 
to work directing it from index.html


